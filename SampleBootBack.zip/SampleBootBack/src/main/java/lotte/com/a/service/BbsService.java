package lotte.com.a.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lotte.com.a.dao.BbsDao;
import lotte.com.a.dto.BbsDto;
import lotte.com.a.dto.BbsParam;
import lotte.com.a.dto.ReplyDto;

@Service
@Transactional
public class BbsService {

	@Autowired
	BbsDao dao;
	
	public List<BbsDto> getBbsList() {
		return dao.getBbsList();
	}
	
	public boolean writeBbs(BbsDto dto) {
		int n = dao.writeBbs(dto);
		return n>0;
	}
	
	public boolean UpdateBbsReact(BbsDto dto) {
		int n = dao.UpdateBbsReact(dto);
		return n>0;
	}
	
	public List<BbsDto> getBbsSearchList(BbsParam param) {
		return dao.getBbsSearchList(param);
	}
	
	public List<BbsDto> getBbsSearchPageList(BbsParam param) {
		return dao.getBbsSearchPageList(param);
	}
	
	public int getBbsCount(BbsParam param) {
		return dao.getBbsCount(param);
	}
	
	public BbsDto getBbsReactdetail(String seq) {
		return dao.getBbsReactdetail(seq);
	}
	
	public boolean answerUpdate(BbsDto dto) {
		int n = dao.answerUpdate(dto);
		return n>0;
	}
	
	public boolean answerInsert(BbsDto dto) {
		int n = dao.answerInsert(dto);
		return n>0;
	}
	
	public boolean deleteBbsReact(String seq) {
		int n = dao.deleteBbsReact(seq);
		return n>0;
	}
	
	public List<ReplyDto> getReply(String seq) {
		return dao.getReply(seq);
	}
	
	public int getReplyCount(String seq) {
		return dao.getReplyCount(seq);
	}
	
	public boolean insertReply(ReplyDto reply) {
		int n = dao.insertReply(reply);
		return n>0;
	}
	
	public boolean deleteReply(String seq) {
		int n = dao.deleteReply(seq);
		return n>0;
	}
	
	public boolean insertview(String id, String bbsseq) {
		int n = dao.insertview(id, bbsseq);
		return n>0;
	}
	
	public int selectview(String bbsseq) {
		return dao.selectview(bbsseq);
	}
}






