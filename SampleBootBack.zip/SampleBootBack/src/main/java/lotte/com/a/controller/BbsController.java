package lotte.com.a.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import lotte.com.a.dto.BbsDto;
import lotte.com.a.dto.BbsParam;
import lotte.com.a.dto.ReplyDto;
import lotte.com.a.service.BbsService;

@RestController
public class BbsController {

	@Autowired
	BbsService service;
	
	@RequestMapping(value = "/getBbsList", method = RequestMethod.GET)
	public List<BbsDto> getBbsList(){
		System.out.println("BbsController getBbsList " + new Date());
		
		List<BbsDto> list = service.getBbsList();
		return list;
	}
	
	@RequestMapping(value = "/writeBbs", method = RequestMethod.GET)
	public String writeBbs(BbsDto dto) {
		System.out.println("BbsController writeBbs " + new Date());
		
		boolean b = service.writeBbs(dto);
		if(!b) {
			return "NO";
		}
		return "OK";
	}	
	
	@RequestMapping(value = "/getBbsSearchList", method = RequestMethod.GET)
	public List<BbsDto> getBbsSearchList(BbsParam param){
		System.out.println("BbsController getBbsSearchList " + new Date());
		
		List<BbsDto> list = service.getBbsSearchList(param);
		return list;
	}
	
	@RequestMapping(value = "/getBbsSearchPageList", method = RequestMethod.GET)
	public List<BbsDto> getBbsSearchPageList(BbsParam param){
		System.out.println("BbsController getBbsSearchPageList " + new Date());
		
		// 페이지 설정
		int sn = param.getPageNumber(); // 0 1 2 3
		int start = sn * 10 + 1;	// 1  11
		int end = (sn + 1) * 10;	// 10 20
		
		param.setStart(start);
		param.setEnd(end);
		
		return service.getBbsSearchPageList(param);		
	}
	
	@RequestMapping(value = "/getBbsCount", method = RequestMethod.GET)
	public int getBbsCount(BbsParam param) {
		System.out.println("BbsController getBbsCount " + new Date());
		
		return service.getBbsCount(param);
	}
	
	@RequestMapping(value = "/getBbsReactPageList", method = RequestMethod.GET)
	public Map<String,Object> getBbsReactPageList(BbsParam param){
		System.out.println("BbsController getBbsReactPageList " + new Date());
		
		// 페이지 설정
		int sn = param.getPageNumber(); // 0 1 2 3
		int start = sn * 10 + 1;	// 1  11
		int end = (sn + 1) * 10;	// 10 20
		
		param.setStart(start);
		param.setEnd(end);
		
		List<BbsDto> list = service.getBbsSearchPageList(param);
		int count = service.getBbsCount(param);
		
		Map<String, Object> map = new HashMap<>();
		map.put("bbslist", list);
		map.put("cnt", count);
		
		return map;
	}
	
	@RequestMapping(value = "/getBbsReactdetail", method = RequestMethod.GET)
	public BbsDto getBbsReactdetail(String seq){
		System.out.println("BbsController getBbsReactdetail " + new Date());
		
		BbsDto dto = service.getBbsReactdetail(seq);
		return dto;
	}
	
	@RequestMapping(value = "/UpdateBbsReact", method = RequestMethod.GET)
	public String UpdateBbsReact(BbsDto dto) {
		System.out.println("BbsController UpdateBbsReact " + new Date());
		
		boolean b = service.UpdateBbsReact(dto);
		if(!b) {
			return "NO";
		}
		return "OK";
	}
	
	@RequestMapping(value = "/answer", method = RequestMethod.GET)
	public String answer(BbsDto dto) {
		System.out.println("BbsController answer " + new Date());
		
		boolean ansUpdate = service.answerUpdate(dto);
		boolean ansInsert = service.answerInsert(dto);
		
		if(!ansUpdate) {
			return "ansUpdate NO";
		}
		
		if(!ansInsert) {
			return "ansInsert No";
		}
		
		return "OK";
	}
	
	@RequestMapping(value = "/deleteBbsReact", method = RequestMethod.GET)
	public String asnwer(String seq) {
		System.out.println("BbsController deleteBbsReact " + new Date());
		boolean delBbs = service.deleteBbsReact(seq);
		if(!delBbs) return "NO";
		return "OK";
	}
	
	@RequestMapping(value = "/getReply", method = RequestMethod.GET)
	public Map<String,Object> getReply(String seq){
		System.out.println("BbsController getReply " + new Date());
		
		List<ReplyDto> list = service.getReply(seq);
		int count = service.getReplyCount(seq);
		
		Map<String, Object> map = new HashMap<>();
		map.put("bbsreply", list);
		map.put("cnt", count);
		
		return map;
	}
	
	@RequestMapping(value = "/insertReply", method = RequestMethod.GET)
	public String insertReply(String id, String content, String bbsSeq){
		System.out.println("BbsController insertReply " + new Date());
		
		boolean count = service.insertReply(new ReplyDto(id,content,bbsSeq));
		if(!count) return "replyNo";
		
		return "replyOK";
	}
	
	@RequestMapping(value = "/deleteReply", method = RequestMethod.GET)
	public String deleteReply(String seq) {
		System.out.println("BbsController deleteReply " + new Date());
		boolean delBbs = service.deleteReply(seq);
		if(!delBbs) return "NO";
		return "OK";
	}
	
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public int view(String id, String bbsseq) {
		System.out.println("BbsController review " + new Date());
		
		boolean ck = service.insertview(id, bbsseq);
		System.out.println("BbsController review " + ck);
		int cnt = service.selectview(bbsseq);
		return cnt;
	}
	
}








