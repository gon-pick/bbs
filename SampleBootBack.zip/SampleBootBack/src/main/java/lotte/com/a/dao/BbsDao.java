package lotte.com.a.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import lotte.com.a.dto.BbsDto;
import lotte.com.a.dto.BbsParam;
import lotte.com.a.dto.ReplyDto;


@Mapper
@Repository
public interface BbsDao {

	List<BbsDto> getBbsList();
	List<BbsDto> getBbsSearchList(BbsParam param);
	
	int writeBbs(BbsDto bto);
	int UpdateBbsReact(BbsDto dto);
	
	List<BbsDto> getBbsSearchPageList(BbsParam param);
	int getBbsCount(BbsParam param);
	
	BbsDto getBbsReactdetail(String seq);
	
	int answerUpdate(BbsDto dto);
	int answerInsert(BbsDto dto);
	int deleteBbsReact(String seq);
	
	//답글
	public List<ReplyDto> getReply(String seq);
	public int getReplyCount(String seq);
	public int insertReply(ReplyDto reply);
	public int deleteReply(String seq);
	
	//리뷰
	public int insertview(String id, String bbsseq);
	public int selectview(String bbsseq);
}
