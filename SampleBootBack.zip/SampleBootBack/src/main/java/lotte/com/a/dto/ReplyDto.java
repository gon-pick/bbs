package lotte.com.a.dto;
/*
create table reply (
	seq int primary key auto_increment,
	id varchar(50),
    content varchar(300),
    wdate timestamp,
    del int,
    bbs_seq int,
    foreign key (bbs_seq) references bbs (seq)
);
 */
public class ReplyDto {
	private int seq;
	private String id;
	private String content;
	private String wdate;
	private int del;
	private String bbsSeq;
	
	public ReplyDto() {
		
	}

	public ReplyDto(int seq, String id, String content, String wdate, int del, String bbsSeq) {
		super();
		this.seq = seq;
		this.id = id;
		this.content = content;
		this.wdate = wdate;
		this.del = del;
		this.bbsSeq = bbsSeq;
	}

	public ReplyDto(String id, String content) {
		super();
		this.id = id;
		this.content = content;
	}

	public ReplyDto(String id, String content, String bbsSeq) {
		super();
		this.id = id;
		this.content = content;
		this.bbsSeq = bbsSeq;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getWdate() {
		return wdate;
	}

	public void setWdate(String wdate) {
		this.wdate = wdate;
	}

	public int getDel() {
		return del;
	}

	public void setDel(int del) {
		this.del = del;
	}

	public String getBbsSeq() {
		return bbsSeq;
	}

	public void setBbsSeq(String bbsSeq) {
		this.bbsSeq = bbsSeq;
	}

	@Override
	public String toString() {
		return "ReplyDto [seq=" + seq + ", id=" + id + ", content=" + content + ", wdate=" + wdate + ", del=" + del
				+ ", bbsSeq=" + bbsSeq + "]";
	}
	
	
}
